<?php
session_start();
require 'config.php';
require 'sessionstore.php';
$id = $_SESSION['id'];

$sql = "SELECT * FROM `details` WHERE `user_id` = '$id'";
$query = mysqli_query($conn, $sql);

$result = mysqli_fetch_assoc($query);

$ipaddress =  $_SERVER['REMOTE_ADDR'];
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>dashboard</title>
  </head>
  <link rel="stylesheet" href="css/dashboard.css" />
  <link rel="stylesheet" href="icofont/icofont.css" />
  <link rel="stylesheet" href="icofont/icofont.min.css" />
  <link rel="stylesheet" href="font-awesome-4.7.0/css/fontawesome.css" />
  <link rel="stylesheet" href="font-awesome-4.7.0/css/fontawesome.min.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
   
    <link rel="stylesheet" href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
  <body>
    <div class="header">
      <div class="navbar"><i class="icofont-navigation-menu"></i></div>
      <div><img src="images/logo_light.png" alt="" class="logo"/></div>
      <div><img src="images/avater.png" alt="" /></div>
    </div>

    <div class="main">
      <div class="nav-links">
        <ul>
          <li>
            <a href=""><i class="fa fa-user"></i> Account</a>
          </li>
          <!-- the user profile should be placed into the acount link -->
          <hr />
          <li>
            <a href=""><i class="fa fa-bar-chart-o"></i> Trade</a>
          </li>
          <hr />
          <li>
            <a href=""><i class="fa fa-history"></i> Trade History</a>
          </li>
          <hr />
          <li >
            <a id="Deposit"><i class="fa fa-cc-mastercard"></i> Deposit</a>
          </li>
          <li class="drop">
            <a href="" class="depo">New Request</a>
          </li>
          <li class="drop">
            <a href="" class="depo"> History</a>
          </li>
          <hr />
          <li>
            <a id="With"><i class="fa fa-diamond"></i> Withdrawals</a>
          </li>
          <li class="Withdrop">
            <a href="" class="depo">New Request</a>
          </li>
          <li class="Withdrop">
            <a href="" class="depo"> History</a>
          </li>
          <hr />
          <li>
            <a href=""><i class="fa fa-chain"></i> Affiliate</a>
          </li>
          <hr />
          <li>
            <a href=""><i class="fa fa-sign-out"></i> Log Out</a>
          </li>
          
        </ul>

        <div id="widget">
        <!-- TradingView Widget BEGIN -->
      <div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
  {
  "colorTheme": "dark",
  "dateRange": "12M",
  "showChart": true,
  "locale": "en",
  "largeChartUrl": "",
  "isTransparent": true,
  "showSymbolLogo": true,
  "showFloatingTooltip": false,
  "width": "270",
  "height": "460",
  "plotLineColorGrowing": "rgba(41, 98, 255, 1)",
  "plotLineColorFalling": "rgba(41, 98, 255, 1)",
  "gridLineColor": "rgba(240, 243, 250, 0)",
  "scaleFontColor": "rgba(120, 123, 134, 1)",
  "belowLineFillColorGrowing": "rgba(41, 98, 255, 0.12)",
  "belowLineFillColorFalling": "rgba(41, 98, 255, 0.12)",
  "belowLineFillColorGrowingBottom": "rgba(41, 98, 255, 0)",
  "belowLineFillColorFallingBottom": "rgba(41, 98, 255, 0)",
  "symbolActiveColor": "rgba(41, 98, 255, 0.12)",
  "tabs": [
    {
      "title": "Indices",
      "symbols": [
        {
          "s": "FOREXCOM:SPXUSD",
          "d": "S&P 500"
        },
        {
          "s": "FOREXCOM:NSXUSD",
          "d": "US 100"
        },
        {
          "s": "FOREXCOM:DJI",
          "d": "Dow 30"
        },
        {
          "s": "INDEX:NKY",
          "d": "Nikkei 225"
        },
        {
          "s": "INDEX:DEU40",
          "d": "DAX Index"
        },
        {
          "s": "FOREXCOM:UKXGBP",
          "d": "UK 100"
        }
      ],
      "originalTitle": "Indices"
    },
    {
      "title": "Futures",
      "symbols": [
        {
          "s": "CME_MINI:ES1!",
          "d": "S&P 500"
        },
        {
          "s": "CME:6E1!",
          "d": "Euro"
        },
        {
          "s": "COMEX:GC1!",
          "d": "Gold"
        },
        {
          "s": "NYMEX:CL1!",
          "d": "Crude Oil"
        },
        {
          "s": "NYMEX:NG1!",
          "d": "Natural Gas"
        },
        {
          "s": "CBOT:ZC1!",
          "d": "Corn"
        }
      ],
      "originalTitle": "Futures"
    },
    {
      "title": "Bonds",
      "symbols": [
        {
          "s": "CME:GE1!",
          "d": "Eurodollar"
        },
        {
          "s": "CBOT:ZB1!",
          "d": "T-Bond"
        },
        {
          "s": "CBOT:UB1!",
          "d": "Ultra T-Bond"
        },
        {
          "s": "EUREX:FGBL1!",
          "d": "Euro Bund"
        },
        {
          "s": "EUREX:FBTP1!",
          "d": "Euro BTP"
        },
        {
          "s": "EUREX:FGBM1!",
          "d": "Euro BOBL"
        }
      ],
      "originalTitle": "Bonds"
    },
    {
      "title": "Forex",
      "symbols": [
        {
          "s": "FX:EURUSD",
          "d": "EUR/USD"
        },
        {
          "s": "FX:GBPUSD",
          "d": "GBP/USD"
        },
        {
          "s": "FX:USDJPY",
          "d": "USD/JPY"
        },
        {
          "s": "FX:USDCHF",
          "d": "USD/CHF"
        },
        {
          "s": "FX:AUDUSD",
          "d": "AUD/USD"
        },
        {
          "s": "FX:USDCAD",
          "d": "USD/CAD"
        }
      ],
      "originalTitle": "Forex"
    }
  ]
}
  </script>
      </div>
        <!-- TradingView Widget END -->
        </div>
      </div>

      <div class="right">
        <div class="alert alert-danger" style="text-align: center;">
            <h5>Verify Your Account To Start Trading</h5>
            <p>Upload any of the (National ID, International Passport, Drivers Licence).
            We will review your document and approve your account as soon as possible.
            </p>
        </div>

        <div class="custoInfo">
            <div>
                <p>Upload ID(front)</p>
                <input type="file">
            </div>

            <div>
                <p>Upload ID(back)</p>
                <input type="file">
            </div>

            <div>
                <p>Upload ID(holding it to your face)</p>
                <input type="file">
            </div>

        </div>

        <div class="AccRev">
            <h3>Account Overview</h3>

           <div class="Con">
             <div class="inner-left">
                <div>
                    <div><i class="fa fas fa-clock-o fa-2x"></i></div>
                    <div><p>Last Login Date:</p>
                    <p><?php echo date('Y/m/d') ?></p>
                    </div>

                </div>
                <div>
                    <div><i class="fa fas fa-dollar fa-2x"></i></div>
                    <div><p>DEMO BALANCE</p>
                    <p>USD <?php echo $result['balance']; ?></p>
                    </div>

                </div>
                <div>
                    <div><i class="fa fas fa-money fa-2x"></i></div>
                    <div><p>LIVE BALANCE</p>
                    <p>USD <?php echo $result['livebalance']?></p>
                    <button class="left_button">MAKE A DEPOSIT</button>
                    </div>

                </div>
                <div>
                    <div><i class="fa fas fa-user fa-2x"></i></div>
                    <div><p>Account Type</p>
                    <p><?php echo $result['package'] ?></p>
                    <button class="left_button">UPGRADE</button>
                    </div>

                </div>
            </div>

            <div class="inner-right">
                <div>
                    <div><i class="fa fas fa-thumb-tack fa-2x"></i></div>
                    <div><p>Your Ip:</p>
                    <p><?php echo $ipaddress?> </p>
                    </div>

                </div>
                <div>
                    <div><i class="fa fas fa-money fa-2x"></i></div>
                    <div><p>BONUS</p>
                    <p> USD  <?php echo $result['bonus']?></p>
                  
                    </div>

                </div>
                <div>
                    <div><i class="fa fas fa-link fa-2x"></i></div>
                    <div><p>Admin Slot</p>
                    <p><?php echo $result['adminslot'] ?></p>
                    <button class="left_button">UPGRADE</button>
                    </div>
                    

                </div>


            </div>
           </div>


        </div>

        </div>
      </div>

      <div class="liveChat_scroll">
        <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "US 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR/USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "Bitcoin"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "Ethereum"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "light",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
      </div>
    </div>
    <script src="js/jquery-3.6.0.js"></script>
 <script src="js/dashboard.js"></script>
  </body>
</html>
