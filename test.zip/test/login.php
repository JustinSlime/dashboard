<?php
session_start();
require 'config.php';

$errormsg = '';
if(isset($_POST['login']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

     // check details
        $checklog = "SELECT * FROM `registered_users` WHERE `email` = '$email' AND `password` = '$password'";
        $logquery = mysqli_query($conn, $checklog);

        if(mysqli_num_rows($logquery) > 0)
        {
            $result = mysqli_fetch_assoc($logquery);

            // session store

            $_SESSION['id'] = $result['id'];
            $_SESSION['firstname'] = $result['firstname'];
            $_SESSION['lastname'] = $result['lastname'];
            $_SESSION['email'] = $result['email'];
            
            header('location:dashboard.php');
        }
        else
        {
            $errormsg = 'This account does not exist';
        }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
    <input type="text" name="email">
    <input type="text" name="password">
    <button name="login">sign up</button>
    <?php echo $errormsg; ?>
    </form>
    
</body>
</html>