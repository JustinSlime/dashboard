$(document).ready(function () {
  $(".drop").fadeOut(0.0001);
  $(".Withdrop").fadeOut(0.0001);
  $("#Deposit").click(function () {
    $(".drop").fadeToggle(100);
  });
  $("#With").click(function () {
    $(".Withdrop").fadeToggle(100);
  });

  $(".icofont-navigation-menu").click(function () {
    $(".nav-links").slideToggle(100);
  });
});
