<?php
session_start();
require 'config.php';

$emailerror = '';
if(isset($_POST['signup']))
{
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

     // check details
    $checkemail = "SELECT * FROM `registered_users` WHERE `email`='$email'";
    $emailquery = mysqli_query($conn, $checkemail);



    if(mysqli_num_rows($emailquery) > 0){
            $emailerror = 'This email already exists';
        }
        else
        {
        // insert details

        $sql = "INSERT INTO `registered_users`(`firstname`, `lastname`, `email`, `password`) VALUES ('$firstname','$lastname','$email','$password')";
        $insert = mysqli_query($conn, $sql);

        // session data
        $select= "SELECT * FROM `registered_users` WHERE `email` = '$email' AND `password` = '$password'" ;
        $selquery = mysqli_query($conn, $select);

        $result = mysqli_fetch_assoc($selquery);
        $_SESSION['id'] = $result['id'];
        $_SESSION['firstname'] = $result['firstname'];
        $_SESSION['lastname'] = $result['lastname'];
        $_SESSION['password'] = $result['password'];

        header('location:complete.php');



        }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
    <input type="text" name="firstname">
    <input type="text" name="lastname">
    <input type="text" name="email">
    <input type="text" name="password">
    <button name="signup">sign up</button>
    <?php echo $emailerror ?>
    </form>
    
</body>
</html>